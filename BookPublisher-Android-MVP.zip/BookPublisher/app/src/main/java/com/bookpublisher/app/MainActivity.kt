package com.bookpublisher.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF172033)
private val Muted = Color(0xFF667085)
private val Violet = Color(0xFF6956D8)
private val Pale = Color(0xFFF5F6FB)
private val Line = Color(0xFFE5E7EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BookPublisherApp(this) }
    }
}

data class BookProject(val title: String, val kind: String, val audience: String, val pages: Int, val quality: String, val status: String)

@Composable
fun BookPublisherApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("book_publisher", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var projects by remember { mutableStateOf(loadProjects(prefs)) }
    var author by remember { mutableStateOf(prefs.getString("author", "") ?: "") }
    var penName by remember { mutableStateOf(prefs.getString("penName", "") ?: "") }
    var marketplace by remember { mutableStateOf(prefs.getString("marketplace", "Amazon.com (US)") ?: "Amazon.com (US)") }
    var bookTitle by remember { mutableStateOf("") }
    var bookKind by remember { mutableStateOf("Coloring book") }
    var audience by remember { mutableStateOf("Ages 4–8") }
    var pageCount by remember { mutableStateOf("50") }
    var artStyle by remember { mutableStateOf("Premium clean line art") }
    var generationTier by remember { mutableStateOf("Free-first (best available)") }
    var bleed by remember { mutableStateOf(true) }
    var trim by remember { mutableStateOf("8.5 × 11 in") }
    var message by remember { mutableStateOf("") }
    var draftPages by remember { mutableStateOf<List<DraftPage>>(emptyList()) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            try { writeInteriorPdf(context, uri, bookTitle.ifBlank { "Untitled Book" }, bookKind, trim, draftPages); message = "Interior PDF exported. Run the KDP checks before publishing." }
            catch (e: Exception) { message = "PDF export failed: ${e.message ?: "unknown error"}" }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Violet, background = Pale, surface = Color.White, onSurface = Ink)) {
        Scaffold(containerColor = Pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = screen == "home", onClick = { screen = "home" }, icon = { Text("⌂", fontSize = 20.sp) }, label = { Text("Studio") })
                NavigationBarItem(selected = screen == "create", onClick = { screen = "create" }, icon = { Text("＋", fontSize = 20.sp) }, label = { Text("New book") })
                NavigationBarItem(selected = screen == "profile", onClick = { screen = "profile" }, icon = { Text("◉", fontSize = 20.sp) }, label = { Text("Profile") })
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "home" -> HomeScreen(projects, onCreate = { screen = "create" }, onProfile = { screen = "profile" }, onOpen = { screen = "create"; bookTitle = it.title })
                    "create" -> CreateScreen(
                        title = bookTitle, onTitle = { bookTitle = it }, kind = bookKind, onKind = { bookKind = it }, audience = audience, onAudience = { audience = it },
                        pages = pageCount, onPages = { pageCount = it }, trim = trim, onTrim = { trim = it }, artStyle = artStyle, onArtStyle = { artStyle = it },
                        tier = generationTier, onTier = { generationTier = it }, bleed = bleed, onBleed = { bleed = it }, message = message,
                        draftPages = draftPages, onGenerateDraft = {
                            val count = pageCount.toIntOrNull() ?: 0
                            if (bookTitle.isBlank()) message = "Enter a working title first."
                            else if (count !in 4..800) message = "Enter a page count between 4 and 800."
                            else { draftPages = buildDraftPages(bookTitle.trim(), bookKind, audience, count); message = "Generated ${draftPages.size} structured draft pages locally. These use template content and vector line art, not AI-generated images." }
                        }, onExportPdf = { if (draftPages.isEmpty()) message = "Generate draft pages first." else exportLauncher.launch(safeFileName(bookTitle.ifBlank { "Book Publisher Interior" }) + "-interior.pdf") },
                        onCreate = {
                            val count = pageCount.toIntOrNull()
                            if (bookTitle.isBlank()) message = "Please enter a working title."
                            else if (count == null || count !in 4..800) message = "Enter a page count between 4 and 800."
                            else {
                                val item = BookProject(bookTitle.trim(), bookKind, audience, count, generationTier, "Setup saved")
                                projects = listOf(item) + projects
                                saveProjects(prefs, projects)
                                message = "Book setup saved on this device. Generate a local draft below, then export an interior PDF."
                            }
                        }
                    )
                    else -> ProfileScreen(author, { author = it }, penName, { penName = it }, marketplace, { marketplace = it }, onSave = {
                        prefs.edit().putString("author", author).putString("penName", penName).putString("marketplace", marketplace).apply()
                        message = "Publishing profile saved on this device."
                    }, message = message)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(projects: List<BookProject>, onCreate: () -> Unit, onProfile: () -> Unit, onOpen: (BookProject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("BOOK PUBLISHER", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Your publishing studio", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Create. Refine. Publish.", color = Muted, fontSize = 14.sp)
                }
                Box(Modifier.size(48.dp).background(Violet, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Text("B", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Ink), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PREMIUM WORKFLOW", color = Color(0xFFC7BDFF), fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                    Text("Turn your next book idea into a print-ready project.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
                    Text("Structured content • Original art • KDP-ready exports", color = Color(0xFFD5D9E5), fontSize = 13.sp)
                    Button(onClick = onCreate, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(14.dp)) { Text("＋  Start a new book", modifier = Modifier.padding(4.dp)) }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("${projects.size}", "Projects", Modifier.weight(1f)); StatCard("3", "Book types", Modifier.weight(1f)); StatCard("PDF", "Export goal", Modifier.weight(1f))
        } }
        item { SectionTitle("Your projects", "Saved locally on this device") }
        if (projects.isEmpty()) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✦", color = Violet, fontSize = 30.sp)
                    Text("Your first book starts here", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Create a setup, choose a quality level, and keep your project details organised.", color = Muted, fontSize = 13.sp)
                    Text("Create first project →", color = Violet, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onCreate() }.padding(8.dp))
                }
            }
        } else items(projects) { project ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(project) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Color(0xFFF0EDFF), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(if (project.kind.contains("Color")) "✎" else if (project.kind.contains("Puzzle")) "◇" else "▤", color = Violet, fontSize = 22.sp) }
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                        Text(project.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
                        Text("${project.kind} • ${project.pages} pages", color = Muted, fontSize = 12.sp)
                        Text(project.status, color = Violet, fontSize = 12.sp)
                    }
                    Text("›", color = Muted, fontSize = 24.sp)
                }
            }
        }
        item { Text("Publishing profile  →", color = Violet, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onProfile() }.padding(vertical = 8.dp)) }
        item { Text("Early build • AI generation, cover editor, PDF export and KDP automation are not active yet.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(17.dp)) { Column(Modifier.padding(14.dp)) { Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink); Text(label, fontSize = 11.sp, color = Muted) } }
}

@Composable private fun SectionTitle(title: String, subtitle: String) { Column(verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink); Text(subtitle, fontSize = 12.sp, color = Muted) } }

@Composable
private fun CreateScreen(title: String, onTitle: (String) -> Unit, kind: String, onKind: (String) -> Unit, audience: String, onAudience: (String) -> Unit,
                         pages: String, onPages: (String) -> Unit, trim: String, onTrim: (String) -> Unit, artStyle: String, onArtStyle: (String) -> Unit,
                         tier: String, onTier: (String) -> Unit, bleed: Boolean, onBleed: (Boolean) -> Unit, message: String, draftPages: List<DraftPage>, onGenerateDraft: () -> Unit, onExportPdf: () -> Unit, onCreate: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("NEW BOOK PROJECT", color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp); Text("Build your book brief", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Set the foundation before generating any pages.", color = Muted, fontSize = 13.sp) }
        item { InputCard("Working title", "Give your book a temporary or final title", title, onTitle) }
        item { ChoiceCard("Book type", listOf("Coloring book", "Activity book", "Puzzle book", "Children's storybook"), kind, onKind) }
        item { ChoiceCard("Target audience", listOf("Toddlers (ages 2–4)", "Ages 4–8", "Ages 8–12", "Teens", "Adults"), audience, onAudience) }
        item { InputCard("Planned interior pages", "For planning only; final count may change", pages, onPages, numeric = true) }
        item { ChoiceCard("Trim size", listOf("8.5 × 11 in", "8 × 10 in", "8.5 × 8.5 in", "6 × 9 in", "Custom (later)"), trim, onTrim) }
        item { ChoiceCard("Illustration direction", listOf("Premium clean line art", "Whimsical storybook", "Bold cartoon", "Minimal modern", "Watercolour-inspired"), artStyle, onArtStyle) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Generation quality", fontWeight = FontWeight.Bold, color = Ink)
                listOf("Free-first (best available)", "Maximum quality within free limits", "Premium quality (not active yet)").forEach { option ->
                    Card(Modifier.fillMaxWidth().clickable { onTier(option) }, colors = CardDefaults.cardColors(containerColor = if (tier == option) Color(0xFFF0EDFF) else Color.White), border = if (tier == option) androidx.compose.foundation.BorderStroke(1.dp, Violet) else androidx.compose.foundation.BorderStroke(1.dp, Line), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = tier == option, onClick = { onTier(option) }); Spacer(Modifier.width(8.dp)); Column { Text(option, fontWeight = FontWeight.SemiBold, color = Ink); if (option == "Premium quality (not active yet)") Text("Not connected in this free-only build. No paid generations will be triggered.", color = Muted, fontSize = 11.sp) } }
                    }
                }
            }
        }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Interior uses bleed", fontWeight = FontWeight.SemiBold); Text("Confirm after page layout is designed.", color = Muted, fontSize = 11.sp) }; Switch(checked = bleed, onCheckedChange = onBleed) } } }
        item { Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text("Save book setup  →") } }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("LOCAL DRAFT & PDF ENGINE", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(if (draftPages.isEmpty()) "No draft pages generated yet" else "${draftPages.size} draft pages ready", fontWeight = FontWeight.Bold, color = Ink)
            Text("Build a structured first draft without an API key, then export an interior PDF using Android's save dialog. This stage uses local templates and vector illustrations; premium AI art will be connected in a later stage.", color = Muted, fontSize = 12.sp)
            Button(onClick = onGenerateDraft, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("Generate local draft pages") }
            OutlinedButton(onClick = onExportPdf, enabled = draftPages.isNotEmpty(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("Export interior PDF") }
        } } }
        if (draftPages.isNotEmpty()) item { SectionTitle("Draft page samples", "First 3 of ${draftPages.size} pages") }
        items(draftPages.take(3)) { page -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Text("Page ${page.number}: ${page.heading}", fontWeight = FontWeight.Bold, color = Ink); Text(page.body, color = Muted, fontSize = 12.sp) } } }
        if (message.isNotBlank()) item { Text(message, color = if (message.startsWith("Book setup")) Color(0xFF287A52) else Color(0xFFB54708), fontSize = 13.sp) }
        item { Text("Prototype status: local template draft and PDF export are available. AI artwork, full-wrap covers and KDP preflight are not yet connected.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun InputCard(label: String, hint: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(label, fontWeight = FontWeight.Bold, color = Ink); OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint, fontSize = 12.sp) }, singleLine = true, shape = RoundedCornerShape(14.dp), keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = if (numeric) androidx.compose.ui.text.input.KeyboardType.Number else androidx.compose.ui.text.input.KeyboardType.Text)) }
}

@Composable private fun ChoiceCard(label: String, options: List<String>, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(label, fontWeight = FontWeight.Bold, color = Ink); Box {
        OutlinedCard(Modifier.fillMaxWidth().clickable { expanded = true }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.outlinedCardColors(containerColor = Color.White)) { Row(Modifier.padding(15.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(selected, Modifier.weight(1f), color = Ink); Text("⌄", color = Violet, fontSize = 20.sp) } }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) } }
    } }
}

@Composable private fun ProfileScreen(author: String, onAuthor: (String) -> Unit, penName: String, onPenName: (String) -> Unit, marketplace: String, onMarketplace: (String) -> Unit, onSave: () -> Unit, message: String) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("PUBLISHING PROFILE", color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp); Text("Your author identity", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Saved details can be reused across future projects.", color = Muted, fontSize = 13.sp) }
        item { InputCard("Legal / account holder name", "Your name for private account records", author, onAuthor) }
        item { InputCard("Author or pen name", "Name shown on your book", penName, onPenName) }
        item { ChoiceCard("Primary marketplace", listOf("Amazon.com (US)", "Amazon.in (India)", "Amazon.co.uk (UK)", "Amazon.ca (Canada)", "Amazon.com.au (Australia)"), marketplace, onMarketplace) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Text("Privacy and publishing note", fontWeight = FontWeight.Bold); Text("This starter keeps the profile on this device. Do not enter your Amazon password or API secrets here. ISBN, rights, tax and AI-content disclosure must be checked before publishing.", color = Muted, fontSize = 12.sp) } } }
        item { Button(onClick = onSave, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text("Save profile") } }
        if (message.isNotBlank()) item { Text(message, color = Color(0xFF287A52), fontSize = 13.sp) }
    }
}


private data class DraftPage(val number: Int, val heading: String, val body: String, val kind: String)

private fun buildDraftPages(title: String, kind: String, audience: String, count: Int): List<DraftPage> {
    return (1..count).map { page ->
        when {
            page == 1 -> DraftPage(page, title, "A first-draft interior for $audience. Review the text, artwork, trim size and print settings before publishing.", kind)
            kind.contains("Color", true) -> DraftPage(page, "Coloring Page $page", "Color the picture. Add your own patterns, background and creative details.", kind)
            kind.contains("Puzzle", true) -> DraftPage(page, "Puzzle Challenge $page", "Challenge: create a sequence using 2, 4, 6, 8, __.\nAnswer key: 10. Review every puzzle before publication.", kind)
            kind.contains("Activity", true) -> DraftPage(page, "Activity $page", "Activity: draw three things you can find in a garden.\nBonus: write one sentence about your favourite.", kind)
            else -> DraftPage(page, "Story Page $page", "Story draft: On a bright morning, a curious little explorer discovered something wonderful. What happens next? Continue the story in your own voice.", kind)
        }
    }
}

private fun safeFileName(value: String): String = value.trim().replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-').ifBlank { "Book-Publisher" }.take(70)

private fun writeInteriorPdf(context: Context, uri: Uri, title: String, kind: String, trim: String, pages: List<DraftPage>) {
    if (pages.isEmpty()) throw IllegalStateException("No draft pages")
    val dims = when (trim) {
        "8 × 10 in" -> Pair(576, 720)
        "8.5 × 8.5 in" -> Pair(612, 612)
        "6 × 9 in" -> Pair(432, 648)
        else -> Pair(612, 792) // 8.5 x 11 inches at 72 points per inch
    }
    val pdf = PdfDocument()
    val ink = android.graphics.Color.BLACK
    val margin = (dims.first * 0.085f)
    pages.forEach { pageData ->
        val info = PdfDocument.PageInfo.Builder(dims.first, dims.second, pageData.number).create()
        val page = pdf.startPage(info)
        val c: Canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 18f; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        if (pageData.number == 1) {
            paint.textSize = 26f
            c.drawText(title.take(38), margin, dims.second * 0.20f, paint)
            paint.textSize = 13f; paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            c.drawText("${kind} • Draft interior", margin, dims.second * 0.20f + 28f, paint)
            paint.textSize = 11f
            c.drawText("Generated with Book Publisher • Review before publishing", margin, dims.second * 0.20f + 55f, paint)
        } else if (pageData.kind.contains("Color", true)) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.2f
            val cx = dims.first / 2f; val cy = dims.second * 0.48f; val radius = minOf(dims.first, dims.second) * 0.20f
            // Simple printable vector flower: deliberately monochrome and scalable.
            for (i in 0 until 8) {
                val a = Math.PI * 2.0 * i / 8.0
                val px = cx + kotlin.math.cos(a).toFloat() * radius * 0.65f
                val py = cy + kotlin.math.sin(a).toFloat() * radius * 0.65f
                c.drawOval(px - radius * 0.30f, py - radius * 0.30f, px + radius * 0.30f, py + radius * 0.30f, paint)
            }
            c.drawCircle(cx, cy, radius * 0.36f, paint)
            c.drawLine(cx, cy + radius * 0.36f, cx, cy + radius * 1.65f, paint)
            c.drawOval(cx - radius * 0.95f, cy + radius * 0.85f, cx - radius * 0.05f, cy + radius * 1.3f, paint)
            c.drawOval(cx + radius * 0.05f, cy + radius * 1.15f, cx + radius * 0.95f, cy + radius * 1.6f, paint)
            paint.style = Paint.Style.FILL; paint.textSize = 16f
            c.drawText(pageData.heading, margin, margin + 15f, paint)
        } else {
            paint.textSize = 18f
            c.drawText(pageData.heading.take(44), margin, margin + 20f, paint)
            paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL); paint.textSize = 14f
            var y = margin + 60f
            pageData.body.split("\n").forEach { line ->
                val words = line.split(" "); var current = ""
                words.forEach { word ->
                    val next = if (current.isEmpty()) word else "$current $word"
                    if (paint.measureText(next) > dims.first - 2 * margin) { c.drawText(current, margin, y, paint); y += 22f; current = word } else current = next
                }
                if (current.isNotEmpty()) { c.drawText(current, margin, y, paint); y += 22f }
                y += 12f
            }
            if (pageData.kind.contains("Puzzle", true)) {
                paint.style = Paint.Style.STROKE
                for (r in 0..3) for (col in 0..3) c.drawRect(margin + col * 42f, y + r * 42f, margin + (col + 1) * 42f, y + (r + 1) * 42f, paint)
                paint.style = Paint.Style.FILL
            } else if (pageData.kind.contains("Activity", true)) {
                paint.style = Paint.Style.STROKE
                repeat(3) { i -> c.drawLine(margin, y + i * 46f, dims.first - margin, y + i * 46f, paint) }
                paint.style = Paint.Style.FILL
            }
        }
        paint.color = ink; paint.textSize = 9f; paint.typeface = android.graphics.Typeface.DEFAULT
        c.drawText("${pageData.number}", dims.first / 2f, dims.second - 18f, paint)
        pdf.finishPage(page)
    }
    context.contentResolver.openOutputStream(uri)?.use { out -> pdf.writeTo(out) } ?: throw IllegalStateException("Unable to open output file")
    pdf.close()
}

private fun loadProjects(prefs: android.content.SharedPreferences): List<BookProject> {
    return try {
        val arr = JSONArray(prefs.getString("projects", "[]"))
        (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); BookProject(o.optString("title"), o.optString("kind"), o.optString("audience"), o.optInt("pages", 50), o.optString("quality"), o.optString("status")) }
    } catch (_: Exception) { emptyList() }
}
private fun saveProjects(prefs: android.content.SharedPreferences, projects: List<BookProject>) {
    val arr = JSONArray(); projects.forEach { p -> arr.put(JSONObject().put("title", p.title).put("kind", p.kind).put("audience", p.audience).put("pages", p.pages).put("quality", p.quality).put("status", p.status)) }
    prefs.edit().putString("projects", arr.toString()).apply()
}
