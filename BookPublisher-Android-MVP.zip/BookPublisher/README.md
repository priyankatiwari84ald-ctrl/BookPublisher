# Book Publisher — Android MVP, milestone 0.2.0

A native Android publishing studio foundation for coloring books, activity books, puzzles, and children's storybooks.

## What works in this milestone
- Kotlin + Jetpack Compose Android app.
- Premium-style studio dashboard and local author profile.
- Book brief: title, book type, audience, page count, trim size, illustration direction, bleed planning, and generation preference.
- Saves project/profile information locally on the device.
- Generates a structured local draft for 4–800 pages without an API key.
- For coloring books, draws simple monochrome vector flower artwork directly in the PDF. Activity and puzzle drafts include writing lines/grid placeholders.
- Exports a PDF interior using Android's system Save dialog.
- Free-first quality is selected by default. No paid AI provider is connected and no paid generation can be triggered in this milestone.

## Important limits
This is an implementation milestone, not a finished KDP production tool. Local draft text is intentionally generic/template-based. The vector flower is a simple demonstration, not premium AI illustration. There is no real AI writing/image provider yet, no full-wrap cover PDF, no current KDP cover-template calculation, no niche research, no cloud sync, and no direct KDP upload. Do not upload generated PDFs to KDP without manual inspection and full print preflight.

## Build on Windows laptop
1. Download and extract `BookPublisher-Android-MVP.zip`.
2. Install Android Studio from the official Android developer website.
3. Open Android Studio → **Open** → choose the extracted `BookPublisher` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish. Use JDK 17 or the compatible JDK bundled with Android Studio. Install Android SDK Platform 35 if prompted.
5. If Android Studio offers a Gradle/plugin update, do not update automatically for this first build; sync the supplied project first.
6. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. When successful, click **Locate** in the notification. Expected path: `app/build/outputs/apk/debug/app-debug.apk`.
8. Transfer the APK to your Android phone, allow installation from that source if Android asks, and install it. Only install APKs you built or trust.

## Use the app
1. Open **New book**.
2. Enter a working title and choose the type, audience, page count, trim size and art direction.
3. Keep **Free-first (best available)** selected.
4. Tap **Save book setup**.
5. In the **Local draft & PDF engine** section, tap **Generate local draft pages**.
6. Tap **Export interior PDF**. Choose a location in the Android Save dialog.
7. Open the PDF and inspect every page. This draft is a prototype and is not automatically KDP-ready.

## Build using an Android phone
Phone-only Android development environments vary. The most reliable route is to build on the Windows laptop and install/test on the phone. If you must build on the phone, use a reputable Android IDE/build environment that supports Gradle, Kotlin, Android SDK 35, and Android Gradle Plugin 8.7.3; open the same project folder and build a debug APK. A plain HTML editor will not build this native project.

## Free-only AI plan for the next milestone
The AI layer will use provider adapters so the app can switch providers. Free access and quotas vary; provider availability must be verified at implementation time. No API key should be hard-coded in Android source. Any service key used from an app should be treated as extractable; production secret keys need a backend or a provider flow designed for client use. The app should show provider limits and never silently select a paid provider.

Package: `com.bookpublisher.app`
Version: `0.2.0`
